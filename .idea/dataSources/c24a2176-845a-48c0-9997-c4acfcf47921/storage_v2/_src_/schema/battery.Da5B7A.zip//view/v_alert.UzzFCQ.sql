create view v_alert as 
select `a`.`alertId` AS `alertId`,`a`.`alertInfo` AS `alertInfo`,`a`.`deviceNo` AS `deviceNo`,`a`.`valid` AS `valid`,`a`.`createTime` AS `createTime`,`a`.`modifyTime` AS `modifyTime`,`d`.`deviceTypeId` AS `deviceTypeId`,`d`.`deviceType` AS `deviceType`,`d`.`deviceTypeDesc` AS `deviceTypeDesc` from (`battery`.`bt_alert` `a` left join `battery`.`v_device` `d` on((`a`.`deviceNo` = `d`.`deviceNo`)));

