create view v_user as 
select `user`.`userId` AS `userId`,`user`.`userName` AS `userName`,`user`.`password` AS `password`,`user`.`name` AS `name`,`user`.`phone` AS `phone`,`user`.`title` AS `title`,`user`.`company` AS `company`,`user`.`roleId` AS `roleId`,`user`.`valid` AS `valid`,`role`.`roleName` AS `roleName` from (`battery`.`bt_user` `user` left join `battery`.`bt_role` `role` on((`user`.`roleId` = `role`.`roleId`)));

