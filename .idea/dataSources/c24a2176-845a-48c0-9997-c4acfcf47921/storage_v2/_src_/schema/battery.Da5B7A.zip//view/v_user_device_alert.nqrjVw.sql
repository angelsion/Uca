create view v_user_device_alert as 
select `ud`.`userId` AS `userId`,`ud`.`deviceId` AS `deviceId`,`ud`.`valid` AS `valid`,`ud`.`deviceNo` AS `deviceNo`,`ud`.`deviceTypeId` AS `deviceTypeId`,`ud`.`deviceType` AS `deviceType`,`ud`.`deviceTypeDesc` AS `deviceTypeDesc`,`a`.`alertInfo` AS `alertInfo`,`a`.`alertId` AS `alertId`,`a`.`createTime` AS `createTime`,`a`.`modifyTime` AS `modifyTime` from (`battery`.`v_user_device` `ud` left join `battery`.`bt_alert` `a` on((`ud`.`deviceNo` = `a`.`deviceNo`)));

