create view v_device as 
select `battery`.`bt_device`.`deviceId` AS `deviceId`,`battery`.`bt_device`.`deviceNo` AS `deviceNo`,`battery`.`bt_device`.`deviceTypeId` AS `deviceTypeId`,`battery`.`bt_device`.`valid` AS `valid`,`battery`.`bt_device_type`.`deviceType` AS `deviceType`,`battery`.`bt_device_type`.`deviceTypeDesc` AS `deviceTypeDesc` from (`battery`.`bt_device` left join `battery`.`bt_device_type` on((`battery`.`bt_device`.`deviceTypeId` = `battery`.`bt_device_type`.`deviceTypeId`)));

