create view v_user_device_location as 
select `ud`.`userId` AS `userId`,`ud`.`deviceId` AS `deviceId`,`ud`.`valid` AS `valid`,`ud`.`deviceNo` AS `deviceNo`,`ud`.`deviceTypeId` AS `deviceTypeId`,`ud`.`deviceType` AS `deviceType`,`ud`.`deviceTypeDesc` AS `deviceTypeDesc`,`a`.`baiduLocation` AS `baiduLocation`,`a`.`gpsLocation` AS `gpsLocation`,`a`.`modifyTime` AS `modifyTime` from (`battery`.`v_user_device` `ud` join `battery`.`bt_device_location` `a` on((`ud`.`deviceNo` = `a`.`deviceNo`)));

