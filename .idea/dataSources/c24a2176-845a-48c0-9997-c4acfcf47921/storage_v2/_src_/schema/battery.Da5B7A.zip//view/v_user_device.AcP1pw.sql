create view v_user_device as 
select `ud`.`userId` AS `userId`,`ud`.`deviceId` AS `deviceId`,`ud`.`valid` AS `valid`,`u`.`name` AS `name`,`u`.`phone` AS `phone`,`u`.`title` AS `title`,`u`.`company` AS `company`,`u`.`roleId` AS `roleId`,`u`.`roleName` AS `roleName`,`d`.`deviceNo` AS `deviceNo`,`d`.`deviceTypeId` AS `deviceTypeId`,`d`.`deviceType` AS `deviceType`,`d`.`deviceTypeDesc` AS `deviceTypeDesc` from ((`battery`.`bt_user_device` `ud` left join `battery`.`v_user` `u` on((`ud`.`userId` = `u`.`userId`))) left join `battery`.`v_device` `d` on((`ud`.`deviceId` = `d`.`deviceId`)));

